Action()
{

	/* 1. Navigate to Blaze demo Ticket Reservation page */
	
	lr_think_time(10);
	
	web_set_max_html_param_len("99999");

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept", 
		"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");

	web_add_header("Accept-Encoding", 
		"gzip, deflate, br, zstd");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.5");
	
	web_reg_save_param_ex(
		"ParamName=C_DepartureCitiesList",
		"LB=<select name=\"fromPort\" class=\"form-inline\">\n            ",
		"RB=\n        </select>",
		SEARCH_FILTERS,
		LAST);
	
	web_reg_save_param_ex(
		"ParamName=C_DestinationCitiesList",
		"LB=<select name=\"toPort\" class=\"form-inline\">\n            ",
		"RB=\n        </select>",
		SEARCH_FILTERS,
		LAST);


	web_reg_find("Search=Body",
		"Text=Welcome to the Simple Travel Agency!",
		LAST);

	
	web_url("www.blazedemo.com", 
		"URL=https://www.blazedemo.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);
	
	lr_save_param_regexp(
		lr_eval_string("{C_DepartureCitiesList}"),
		strlen(lr_eval_string("{C_DepartureCitiesList}")), 
		"RegEXP=<option value=\"(.*?)\">",
		"Ordinal=All",
		"ResultParam=C_DepartureCitiesArray",
		LAST);
	
	lr_save_param_regexp(
		lr_eval_string("{C_DestinationCitiesList}"),
		strlen(lr_eval_string("{C_DestinationCitiesList}")), 
		"RegEXP=<option value=\"(.*?)\">",
		"Ordinal=All",
		"ResultParam=C_DestinationCitiesArray",
		LAST);	
	
	//lr_paramarr_random("C_DepartureCitiesArray");
	//lr_paramarr_random("C_DestinationCitiesArray");

	web_add_auto_header("Accept", 
		"*/*");

	web_add_header("Accept-Encoding", 
		"gzip, deflate");

	web_add_header("Cache-Control", 
		"no-cache");
	
	
	web_url("www.blazedemo.com_2", 
		"URL=http://www.blazedemo.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://www.blazedemo.com/favicon.ico", "Referer=https://www.blazedemo.com/", ENDITEM, 
		LAST);
	
	RandomCitySelection:
   	lr_save_string(lr_paramarr_random("C_DepartureCitiesArray"),"C_depart");
	lr_save_string(lr_paramarr_random("C_DestinationCitiesArray"),"C_destination");
	
	
//Code to verify C_depart and C_destination are same.

if(strcmp(lr_eval_string("{C_depart}"),lr_eval_string("{C_destination}"))==0)
   
   {
	   	lr_output_message("Both cities are same");
	   	goto RandomCitySelection; 
	   	
   }
		
	return 0;
	
	/* 2.Select Departure city, Destination city randomly from each dropdown and click Find Flights */
	
	lr_think_time(10);

	web_add_auto_header("Accept", 
		"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");

	web_add_auto_header("Accept-Encoding", 
		"gzip, deflate, br, zstd");

	web_reg_find("Search=Body",
		"Text=Choose",
		LAST);

	web_submit_data("reserve.php", 
		"Action=https://www.blazedemo.com/reserve.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://www.blazedemo.com/", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=fromPort", "Value=Portland", ENDITEM, 
		"Name=toPort", "Value=Berlin", ENDITEM, 
		LAST);

	/* 3.Choose a Flight randomly */
	
	lr_think_time(10);

	web_reg_find("Search=Body",
		"Text=Please submit the form below to purchase the flight.",
		LAST);

	web_submit_data("purchase.php", 
		"Action=https://www.blazedemo.com/purchase.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://www.blazedemo.com/reserve.php", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=flight", "Value=12", ENDITEM, 
		"Name=price", "Value=765.32", ENDITEM, 
		"Name=airline", "Value=Virgin America", ENDITEM, 
		"Name=fromPort", "Value=Portland", ENDITEM, 
		"Name=toPort", "Value=Berlin", ENDITEM, 
		LAST);

	/* 4.Enter User info, Payment details and Click Purchase Ticket */
	
	lr_think_time(10);

	web_reg_find("Search=Body",
		"Text=Thank you for your purchase today!",
		LAST);

	web_submit_data("confirmation.php", 
		"Action=https://www.blazedemo.com/confirmation.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://www.blazedemo.com/purchase.php", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_token", "Value=", ENDITEM, 
		"Name=inputName", "Value={P_inputName}", ENDITEM, 
		"Name=address", "Value={P_address}", ENDITEM, 
		"Name=city", "Value={P_city}", ENDITEM, 
		"Name=state", "Value={P_state}", ENDITEM, 
		"Name=zipCode", "Value={P_zipCode}", ENDITEM, 
		"Name=cardType", "Value={P_cardType}", ENDITEM, 
		"Name=creditCardNumber", "Value={P_creditCardNumber}", ENDITEM, 
		"Name=creditCardMonth", "Value={P_creditCardMonth}", ENDITEM, 
		"Name=creditCardYear", "Value={P_creditCardYear}", ENDITEM, 
		"Name=nameOnCard", "Value={P_inputName}", ENDITEM, 
		LAST);

	return 0;
}