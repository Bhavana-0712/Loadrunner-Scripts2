Action()
{
	
	/* 1.Login to Web Tours */
	lr_think_time(10);
	lr_start_transaction("BookTicket_DenverToParis_TO1_NavigatetoWeb-Tours");

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept", 
		"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");

	web_add_auto_header("Accept-Encoding", 
		"gzip, deflate, br, zstd");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.5");

//<input type="hidden" name="userSession" value="{C_userSession}"/>

	web_reg_save_param_ex(
		"ParamName=C_userSession",
		"LB=userSession\" value=\"",
		"RB=\"",
		SEARCH_FILTERS,
		LAST);
	
	web_reg_find("Search=Body",
		"Text=Welcome to the Web Tours site.",
		LAST);

	web_url("index.htm", 
		"URL=http://localhost:1080/WebTours/index.htm", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(10);
		
// Welcome, <b>jojo</b>, to the Web Tours reservation pages.

		web_reg_find("Search=All",
		"Text=Welcome, <b>{P_uname}</b>, to the Web Tours reservation pages.",
		LAST);

	web_submit_data("login.pl", 
		"Action=http://localhost:1080/cgi-bin/login.pl", 
		"Method=POST", 
		"TargetFrame=body", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?in=home", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=userSession", "Value={C_userSession}", ENDITEM, 
		"Name=username", "Value={P_uname}", ENDITEM, 
		"Name=password", "Value={P_paswd}", ENDITEM, 
		"Name=login.x", "Value=39", ENDITEM, 
		"Name=login.y", "Value=11", ENDITEM, 
		"Name=JSFormSubmit", "Value=off", ENDITEM, 
		LAST);

	lr_end_transaction("BookTicket_DenverToParis_TO1_NavigatetoWeb-Tours",LR_AUTO);
	
	/* 2.Click Flights Button */
	
	lr_think_time(10);
	lr_start_transaction("BookTicket_DenverToParis_TO2_Click Flights Button");

	web_reg_find("Search=Body",
		"Text=Find Flight",
		LAST);

	web_url("Search Flights Button", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?page=search", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("BookTicket_DenverToParis_TO2_Click Flights Button",LR_AUTO);
	
	/* 3.Select Paris as Arrival city & Continue */

	lr_think_time(10);
	
	lr_start_transaction("BookTicket_DenverToParis_TO3_Selectarrivalcity");
	
		web_reg_find("Search=Body",
		"Text=Flight departing from ",
		LAST);
	
//name="outboundFlight" value="040;508;06/22/2025" 

	 web_reg_save_param_ex(
		"ParamName=C_outboundFlight",
		"LB=outboundFlight\" value=\"",
		"RB=\"",
		SEARCH_FILTERS,
		LAST);

	
	web_submit_data("reservations.pl", 
		"Action=http://localhost:1080/cgi-bin/reservations.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/reservations.pl?page=welcome", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=depart", "Value=Denver", ENDITEM, 
		"Name=departDate", "Value={P_departDate}", ENDITEM, 
		"Name=arrive", "Value=Paris", ENDITEM, 
		"Name=returnDate", "Value={P_returnDate}", ENDITEM, 
		"Name=numPassengers", "Value={P_numpassengers}", ENDITEM, 
		"Name=seatPref", "Value=Window", ENDITEM, 
		"Name=seatType", "Value=Business", ENDITEM, 
		"Name=findFlights.x", "Value=54", ENDITEM, 
		"Name=findFlights.y", "Value=9", ENDITEM, 
		"Name=.cgifields", "Value=roundtrip", ENDITEM, 
		"Name=.cgifields", "Value=seatType", ENDITEM, 
		"Name=.cgifields", "Value=seatPref", ENDITEM, 
		LAST);

	lr_end_transaction("BookTicket_DenverToParis_TO3_Selectarrivalcity",LR_AUTO);

	/* 4.Select Morning flight */

	lr_think_time(10);
	lr_start_transaction("BookTicket_DenverToParis_TO4_SelectMorningFlight");

	web_reg_find("Search=Body",
		"Text=Payment Details",
		LAST);

	web_submit_data("reservations.pl_2", 
		"Action=http://localhost:1080/cgi-bin/reservations.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/reservations.pl", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=outboundFlight", "Value={C_outboundFlight}", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=seatType", "Value=Business", ENDITEM, 
		"Name=seatPref", "Value=Window", ENDITEM, 
		"Name=reserveFlights.x", "Value=72", ENDITEM, 
		"Name=reserveFlights.y", "Value=8", ENDITEM, 
		LAST);

	lr_end_transaction("BookTicket_DenverToParis_TO4_SelectMorningFlight",LR_AUTO);
	
	/* 5.Enter Payment details */

	lr_think_time(10);
	lr_start_transaction("BookTicket_DenverToParis_TO5_EnterPaymentDetails");

	web_reg_find("Search=Body",
		"Text=Invoice",
		LAST);

	web_submit_data("reservations.pl_3", 
		"Action=http://localhost:1080/cgi-bin/reservations.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/reservations.pl", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=firstName", "Value=Ram", ENDITEM, 
		"Name=lastName", "Value=Sharma", ENDITEM, 
		"Name=address1", "Value=Mita Road,Sector-21", ENDITEM, 
		"Name=address2", "Value=Mumbai/Maharashtra/423765", ENDITEM, 
		"Name=pass1", "Value=Ram Sharma", ENDITEM, 
		"Name=creditCard", "Value=1234567891234567", ENDITEM, 
		"Name=expDate", "Value=03/30", ENDITEM, 
		"Name=oldCCOption", "Value=", ENDITEM, 
		"Name=numPassengers", "Value={P_numpassengers}", ENDITEM, 
		"Name=seatType", "Value=Business", ENDITEM, 
		"Name=seatPref", "Value=Window", ENDITEM, 
		"Name=outboundFlight", "Value={C_outboundFlight}", ENDITEM, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=returnFlight", "Value=", ENDITEM, 
		"Name=JSFormSubmit", "Value=off", ENDITEM, 
		"Name=buyFlights.x", "Value=48", ENDITEM, 
		"Name=buyFlights.y", "Value=8", ENDITEM, 
		"Name=.cgifields", "Value=saveCC", ENDITEM, 
		LAST);

	lr_end_transaction("BookTicket_DenverToParis_TO5_EnterPaymentDetails",LR_AUTO);
	
	/* 6.Sign off */
 
	lr_think_time(10);
	lr_start_transaction("BookTicket_DenverToParis_TO6_Logoff");

	web_reg_find("Search=Body",
		"Text=Password",
		LAST);

	web_url("SignOff Button", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?signOff=1", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=flights", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("BookTicket_DenverToParis_TO6_Logoff",LR_AUTO);
	return 0;
}