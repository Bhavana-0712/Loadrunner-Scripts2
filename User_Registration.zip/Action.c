Action()
{

	/*1. Konakart_Application_Launching */
	
	lr_think_time(10);
	lr_start_transaction("Konakart_TO1_ApplicationLaunching");


	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.5");

	web_reg_find("Search=Body",
		"Text=Sign In",
		LAST);

	web_url("LogIn.action", 
		"URL=https://www.konakart.com/konakart/LogIn.action", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);
	
lr_end_transaction("Konakart_TO1_ApplicationLaunching",LR_AUTO);
	
	
	
	/* 2. Click on RegisteranAccount. */

	lr_think_time(10);
	lr_start_transaction("Konakart_TO2_ClickonRegisterAccount");

	web_reg_find("Search=Body",
		"Text=New Account",
		LAST);

	web_url("Register an account", 
		"URL=https://www.konakart.com/konakart/CustomerRegistration.action?forceReg=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.konakart.com/konakart/LogIn.action", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("Konakart_TO2_ClickonRegisterAccount",LR_AUTO);
	
	/* 3. Enter User Details and click Continue. */

	lr_think_time(10);
    lr_start_transaction("Konakart_TO3_EnterUserDetails");
	
	

	web_reg_find("Search=Body",
		"Text=New Account",
		LAST);

	web_submit_data("CustomerRegistrationSubmit.action", 
		"Action=https://www.konakart.com/konakart/CustomerRegistrationSubmit.action", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://www.konakart.com/konakart/CustomerRegistration.action?forceReg=true", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=xsrf_token", "Value=null", ENDITEM, 
		"Name=allowNoRegister", "Value=false", ENDITEM, 
		"Name=gender", "Value={Cr_gender}", ENDITEM, 
		"Name=firstName", "Value={Cr_firstName}", ENDITEM, 
		"Name=lastName", "Value={Cr_lastName}", ENDITEM, 
		"Name=birthDateString", "Value={Cr_birthDateString}", ENDITEM, 
		"Name=emailAddr", "Value={Cr_emailAddr}", ENDITEM, 
		"Name=username", "Value={Cr_username}", ENDITEM, 
		"Name=company", "Value=", ENDITEM, 
		"Name=taxId", "Value=", ENDITEM, 
		"Name=streetAddress", "Value={Cr_streetAddress}", ENDITEM, 
		"Name=streetAddress1", "Value=", ENDITEM, 
		"Name=suburb", "Value=", ENDITEM, 
		"Name=postcode", "Value={Cr_postcode}", ENDITEM, 
		"Name=city", "Value={Cr_city}", ENDITEM, 
		"Name=countryId", "Value={Cr_countryId}", ENDITEM, 
		"Name=telephoneNumber", "Value=", ENDITEM, 
		"Name=telephoneNumber1", "Value=", ENDITEM, 
		"Name=faxNumber", "Value=", ENDITEM, 
		"Name=__checkbox_newsletterBool", "Value=true", ENDITEM, 
		"Name=password", "Value=", ENDITEM, 
		"Name=passwordConfirmation", "Value=", ENDITEM, 
		"Name=countryChange", "Value=1", ENDITEM, 
		LAST);

	// lr_think_time(10);

	web_custom_request("ValidateAddress.action", 
		"URL=https://www.konakart.com/konakart/ValidateAddress.action", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.konakart.com/konakart/CustomerRegistrationSubmit.action", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"streetAddress\":\"{Cr_streetAddress}\",\"streetAddress1\":\"\",\"suburb\":\"\",\"postcode\":\"{Cr_postcode}\",\"city\":\"{Cr_city}\",\"state\":\"Maharashtra\",\"countryId\":\"{Cr_countryId}\",\"xsrf_token\":\"null\"}", 
		EXTRARES, 
		"Url=images/icons/required-green.png", "Referer=https://www.konakart.com/konakart/styles/kk-style.css", ENDITEM, 
		LAST);

	/*	web_reg_find("Search=Body",
		"Text=My Account Information",
		LAST); */

	web_submit_data("CustomerRegistrationSubmit.action_2", 
		"Action=https://www.konakart.com/konakart/CustomerRegistrationSubmit.action", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://www.konakart.com/konakart/CustomerRegistrationSubmit.action", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=xsrf_token", "Value=null", ENDITEM, 
		"Name=allowNoRegister", "Value=false", ENDITEM, 
		"Name=gender", "Value={Cr_gender}", ENDITEM, 
		"Name=firstName", "Value={Cr_firstName}", ENDITEM, 
		"Name=lastName", "Value={Cr_lastName}", ENDITEM, 
		"Name=birthDateString", "Value={Cr_birthDateString}", ENDITEM, 
		"Name=emailAddr", "Value={Cr_emailAddr}", ENDITEM, 
		"Name=username", "Value={Cr_username}", ENDITEM, 
		"Name=company", "Value=", ENDITEM, 
		"Name=taxId", "Value=", ENDITEM, 
		"Name=streetAddress", "Value={Cr_streetAddress}", ENDITEM, 
		"Name=streetAddress1", "Value=", ENDITEM, 
		"Name=suburb", "Value=", ENDITEM, 
		"Name=postcode", "Value={Cr_postcode}", ENDITEM, 
		"Name=city", "Value={Cr_city}", ENDITEM, 
		"Name=state", "Value=Maharashtra", ENDITEM, 
		"Name=countryId", "Value={Cr_countryId}", ENDITEM, 
		"Name=telephoneNumber", "Value={Cr_telephoneNumber}", ENDITEM, 
		"Name=telephoneNumber1", "Value=", ENDITEM, 
		"Name=faxNumber", "Value=", ENDITEM, 
		"Name=__checkbox_newsletterBool", "Value=true", ENDITEM, 
		"Name=password", "Value={Cr_password}", ENDITEM, 
		"Name=passwordConfirmation", "Value={Cr_password}", ENDITEM, 
		"Name=countryChange", "Value={Cr_countryChange}", ENDITEM, 
		EXTRARES, 
		"Url=images/loader.gif", "Referer=https://www.konakart.com/konakart/styles/kk-style.css", ENDITEM, 
		LAST);

	lr_end_transaction("Konakart_TO3_EnterUserDetails",LR_AUTO);
	
	/* 4.Logout */

	lr_think_time(10);
	lr_start_transaction("Konakart_TO4_Logout");

	web_reg_find("Search=Body",
		"Text=Log Off",
		LAST);

	web_url("Log Off", 
		"URL=https://www.konakart.com/konakart/LogOut.action", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.konakart.com/konakart/CustomerRegistrationSubmit.action", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("Konakart_TO4_Logout",LR_AUTO);
	
	return 0;
}